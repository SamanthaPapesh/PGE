package com.example.attempt2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView; //library added for TextView
import android.media.MediaPlayer; //library to implement the use of audio & video files
import com.google.android.material.slider.Slider; //library for material slider


public class MainActivity extends AppCompatActivity {

    //Declare & Initialize Variables
    int number_of_clicks = 0;
    int volume = 0;
    MediaPlayer sound;
    int pauseSound;

    //Declare Sliders & Corresponding TextViews
    Slider Mod1Slider;
    TextView Mod1ProgressValueText;
    Slider Mod2Slider;
    TextView Mod2ProgressValueText;
    Slider Mod3Slider;
    TextView Mod3ProgressValueText;
    Slider Mod4Slider;
    TextView Mod4ProgressValueText;
    Slider Mod5Slider;
    TextView Mod5ProgressValueText;
    Slider Mod6Slider;
    TextView Mod6ProgressValueText;
    Slider Mod7Slider;
    TextView Mod7ProgressValueText;
    Slider Mod8Slider;
    TextView Mod8ProgressValueText;
    Slider Mod9Slider;
    TextView Mod9ProgressValueText;
    Slider Mod10Slider;
    TextView Mod10ProgressValueText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Slider1: Initialize & Method for Obtaining Thumb Status
        Mod1Slider = (Slider) findViewById(R.id.Mod1);
        Mod1ProgressValueText = (TextView) findViewById(R.id.textView1);
        Mod1Slider.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(@NonNull Slider slider) { } //do nothing
            //Record Current Thumb Status
            @Override
            public void onStopTrackingTouch(@NonNull Slider slider) {
                float Mod1Value = slider.getValue();
                //Debug to View Variable Value on Screen
                Mod1ProgressValueText.setText("Progress: " +Mod1Value);
                //Debug to View Variable Value in "Logcat"
                Log.d("*Modulator 1 value = ", Mod1Value+".");
                //Write SEND Code to Pi Here
            }
        }); //End of Slider1 Method

    }

    //Method for LED Control
    public void onClickLED(View view) {
        //Method: section of code to execute over & over again
        //LED Switch Program executed when LED_button is clicked
        TextView text = (TextView) findViewById(R.id.textView0);
        number_of_clicks++; //changing variable
        //LED Cases: (0) OFF, (1) Red, (2) Blue, (3) Green, (4) Yellow, (5) Purple, (6) Cyan, (7) White, (8) Light Show.
        if (number_of_clicks == 0) { //(0) OFF
            text.setText("LEDs: OFF.\nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 1) { //(1) Red
            text.setText("RED. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 2) { //(2) Blue
            text.setText("BLUE. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 3) { //(3) Green
            text.setText("GREEN. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 4) { //(4) Yellow
            text.setText("YELLOW. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 5) { //(5) Purple
            text.setText("PURPLE. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 6) { //(6) Cyan
            text.setText("CYAN. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 7) { //(7) White
            text.setText("White. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks == 8) { //(8) Light Show
            text.setText("Light Show. \nClick Count: "+number_of_clicks+ ".");}
        if (number_of_clicks > 8) { //Return to Beginning, "(0) OFF"
            number_of_clicks = 0; text.setText("LEDs OFF. \nClick Count: "+number_of_clicks+ ".");}
        } //End of LED EVENT LISTENER


    //Methods for Volume Control
    public void OnClickVolumeUp(View view) {
        TextView text = (TextView) findViewById(R.id.textViewVolume);
        if(volume<=9) {
            volume = volume+1;
            text.setText("V:"+volume+".");}
        if(volume>=10) {text.setText("Max.");}
    }
    public void OnClickVolumeDown(View view) {
        TextView text = (TextView) findViewById(R.id.textViewVolume);
        if(volume == 0) {text.setText("V:"+volume+".");}
        else {
            volume = volume-1;
            text.setText("V:"+volume+".");}
    }

    //Method for Opening & Closing the User Manual
    public void UserManualFunction(View view) {
        //Method for User Manual Pop-Up Content
        //startActivity(new Intent(MainActivity.this,pop.class));
    }
}